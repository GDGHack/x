 class Saving {
    private static double airate;
    private double sbalance;

    // Constructor name fixed
    Saving(double sbalance) {
        this.sbalance = sbalance;
    }

    public double calairate() {
        double interest = (sbalance * airate) / 12;
        sbalance += interest;
        return sbalance;
    }

    // Return type added (void)
    public static void modifyairate(double newairate) {
        airate = newairate / 100;
    }

    public double getsbalance() {
        return sbalance;
    }
}

public class SavingsAccountTest {
    public static void main(String[] args) {
        Saving obj1 = new Saving(2000);
        Saving obj2 = new Saving(3000);

        System.out.println("Initial Balance:");
        System.out.println(obj1.getsbalance());
        System.out.println(obj2.getsbalance());

        System.out.println("\nAfter modifying annual interest rate to 4%:");
        Saving.modifyairate(4);
        System.out.println(obj1.calairate());
        System.out.println(obj2.calairate());

        System.out.println("\nAfter modifying annual interest rate to 5%:");
        Saving.modifyairate(5);
        System.out.println(obj1.calairate());
        System.out.println(obj2.calairate());
    }
}
