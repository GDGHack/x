abstract class Shape {
	double side, area, perimeter;
	
	Shape(double side) {
		this.side = side;
	}
	
	abstract void calArea();
	abstract void calPeri();
	
	void display() {
		System.out.println("Perimeter : " + perimeter);
		System.out.println("Area : " + area);
	}
}


class triangle extends Shape{
	double height;
	triangle(double base, double height) {
		super(base);
		this.height = height;
	}
	
	void calArea() {
		area = (side * height)/2;
	}
	
	void calPeri() {
		perimeter = 3 * side;
	}
	
	void display() {
		System.out.println("Details of Trianlge : ");
		super.display();
	}
}


class EXP_03 {
	public static void main(String[] args) {
		Shape s;
		
		s = new triangle(2, 3);
		s.calArea();
		s.calPeri();
		s.display();
	}
}


	