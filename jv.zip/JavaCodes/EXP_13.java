import java.io.*;
import java.util.*;

public class EXP_13 {
	public static void main(String[] args) {
		LinkedList <String> lines = new LinkedList<>();
		
		try {
			BufferedReader br = new BufferedReader(new FileReader("file.txt"));
			String line;
			
			while((line = br.readLine()) != null) {
				lines.add(line);
			}
			br.close();
			
			ListIterator<String> iterator = lines.listIterator(lines.size());
			while(iterator.hasPrevious()) {
				System.out.println(iterator.previous());
			}
		} catch (IOException e) {
			System.out.println(e.getMessage());
		}
	}

}
			