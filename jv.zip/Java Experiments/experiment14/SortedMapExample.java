import java.util.*;

public class SortedMapExample {
    public static void main(String[] args) {
        // Step 1: Create and fill a HashMap
        HashMap<String, Integer> hashMap = new HashMap<>();
        hashMap.put("banana", 3);
        hashMap.put("apple", 5);
        hashMap.put("cherry", 2);
        hashMap.put("date", 7);

        // Step 2: Print original HashMap (unordered)
        System.out.println("Original HashMap (unordered):");
        for (Map.Entry<String, Integer> entry : hashMap.entrySet()) {
            System.out.println(entry.getKey() + " => " + entry.getValue());
        }

        // Step 3: Extract entries and sort by key
        List<Map.Entry<String, Integer>> sortedEntries = new ArrayList<>(hashMap.entrySet());
        sortedEntries.sort(Map.Entry.comparingByKey());

        // Step 4: Insert into LinkedHashMap to maintain insertion order
        LinkedHashMap<String, Integer> linkedHashMap = new LinkedHashMap<>();
        for (Map.Entry<String, Integer> entry : sortedEntries) {
            linkedHashMap.put(entry.getKey(), entry.getValue());
        }

        // Step 5: Print LinkedHashMap (in sorted key order)
        System.out.println("\nLinkedHashMap (sorted by key, insertion order maintained):");
        for (Map.Entry<String, Integer> entry : linkedHashMap.entrySet()) {
            System.out.println(entry.getKey() + " => " + entry.getValue());
        }
    }
}
