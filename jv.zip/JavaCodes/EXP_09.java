import java.util.*;
import java.io.*;

class Student implements Serializable {
	String name;
	int age;
	double weight;
	double height;
	String city;
	String phone;
	
	public Student(String name, int age, double weight, double height, String city, String phone) {
        this.name = name;
        this.age = age;
        this.weight = weight;
        this.height = height;
        this.city = city;
        this.phone = phone;
    }
	
	public void display() {
        System.out.println("----- Student Details -----");
        System.out.println("Name   : " + name);
        System.out.println("Age    : " + age);
        System.out.println("Weight : " + weight + " kg");
        System.out.println("Height : " + height + " cm");
        System.out.println("City   : " + city);
        System.out.println("Phone  : " + phone);
    }
}

public class EXP_09 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		
		System.out.print("Enter name: ");
        String name = sc.nextLine();

        System.out.print("Enter age: ");
        int age = sc.nextInt();

        System.out.print("Enter weight (in kg): ");
        double weight = sc.nextDouble();

        System.out.print("Enter height (in cm): ");
        double height = sc.nextDouble();
        sc.nextLine(); 

        System.out.print("Enter city: ");
        String city = sc.nextLine();

        System.out.print("Enter phone number: ");
        String phone = sc.nextLine();
		
		Student student = new Student(name, age, weight, height, city, phone);
		
		
		try(FileOutputStream fos = new FileOutputStream("student.dat");
			DataOutputStream dos = new DataOutputStream(fos)) {
			
			dos.writeUTF(student.name);
			dos.writeInt(student.age);
			dos.writeDouble(student.weight);
			dos.writeDouble(student.height);
			dos.writeUTF(student.city);
			dos.writeUTF(student.phone);
			
			System.out.println("Student data saved successfully to file.\n");
        } catch (IOException e) {
            System.out.println("Error writing to file: " + e.getMessage());
        }
		
		try (FileInputStream fis = new FileInputStream("student.dat");
			 DataInputStream dis = new DataInputStream(fis)) {
				 
			String readName = dis.readUTF();
			int readAge = dis.readInt();
            double readWeight = dis.readDouble();
            double readHeight = dis.readDouble();
            String readCity = dis.readUTF();
            String readPhone = dis.readUTF();
			
			Student retrievedStudent = new Student(readName, readAge, readWeight, readHeight, readCity, readPhone);
            retrievedStudent.display();

		} catch (IOException e) {
			System.out.println("Error reading from file: " + e.getMessage());
		}
		sc.close();
	}
}