import java.util.*;

class SavingAccount {
    static double annualInterestRate; // Static variable for interest rate
    private double savingBalance;  // Instance variable for balance

    // Constructor to initialize balance
    public SavingAccount(double balance) {
        this.savingBalance = balance;
    }

    // Method to calculate and apply monthly interest
    public void calculateMonthlyInterest() {
        double monthlyInterest = (savingBalance * annualInterestRate) / 12;
        savingBalance += monthlyInterest;
    }

    // Static method to modify the interest rate
    public static void modifyInterestRate(double newRate) {
        annualInterestRate = newRate;
    }

    // Method to get the current balance
    public double getBalance() {
        return savingBalance;
    }
}

public class TestSavingAccount {
    public static void main(String[] args) {
        // Create two SavingAccount objects
        SavingAccount saver1 = new SavingAccount(2000);
        SavingAccount saver2 = new SavingAccount(3000);

        // Scanner to take user input
        Scanner sc = new Scanner(System.in);

        // Input for first interest rate change
        System.out.print("Enter the Modified Interest Rate: ");
        double newRate1 = sc.nextDouble();
        SavingAccount.modifyInterestRate(newRate1);  // Modify interest rate

        // Display results after first interest rate change
        System.out.println("After first interest rate change:");
        System.out.println("Annual Interest Rate: " + SavingAccount.annualInterestRate);  // Using class reference
        saver1.calculateMonthlyInterest();
        System.out.println("Saver 1 Balance: " + saver1.getBalance());
        saver2.calculateMonthlyInterest();
        System.out.println("Saver 2 Balance: " + saver2.getBalance());

        // Input for second interest rate change
        System.out.print("\nEnter the Modified Interest Rate: ");
        double newRate2 = sc.nextDouble();
        SavingAccount.modifyInterestRate(newRate2); // Modify interest rate again

        // Display results after second interest rate change
        System.out.println("\nAfter second interest rate change:");
        System.out.println("Annual Interest Rate: " + SavingAccount.annualInterestRate);  // Using class reference
        saver1.calculateMonthlyInterest();
        System.out.println("Saver 1 Balance: " + saver1.getBalance());
        saver2.calculateMonthlyInterest();
        System.out.println("Saver 2 Balance: " + saver2.getBalance());

        // Close the scanner object to avoid resource leak
        sc.close();
    }
}
