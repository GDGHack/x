import java.util.*;
import java.io.*;

public class EXP_14 {
	public static void main(String[] args) {
		HashMap <String, Integer> hashMap = new HashMap<>();
		hashMap.put("banana", 2);
		hashMap.put("apple", 3);
		hashMap.put("grapes", 5);
		hashMap.put("Watermelon", 1);
		
		System.out.println("Original HashMap (unordered):");
		
		for(Map.Entry<String, Integer> entry: hashMap.entrySet()) {
			System.out.println(entry.getKey() + " => " + entry.getValue());
		}
		
		List<Map.Entry<String, Integer>> sortedEntries = new ArrayList<>(hashMap.entrySet());
		sortedEntries.sort(Map.Entry.comparingByKey());
		
		LinkedHashMap<String, Integer> linkedHashMap = new LinkedHashMap<>();
		for(Map.Entry<String, Integer> entry : sortedEntries) {
			linkedHashMap.put(entry.getKey(), entry.getValue());
		}
		
		System.out.println("\nLinkedHashMap (sorted by key, insertion order maintained):");
		for (Map.Entry<String, Integer> entry : linkedHashMap.entrySet()) {
			System.out.println(entry.getKey() + " => " + entry.getValue());
		}
	}
}