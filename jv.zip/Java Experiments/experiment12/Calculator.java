import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Calculator {
    public static void main(String[] args) {
        JFrame f = new JFrame("Calculator");
        f.setSize(300, 400);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JTextField display = new JTextField();
        display.setEditable(false);
        display.setFont(new Font("Arial", Font.BOLD, 24));
        f.add(display, BorderLayout.NORTH);

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(4, 4, 5, 5));

        String[] buttons = {
            "7", "8", "9", "/",
            "4", "5", "6", "*",
            "1", "2", "3", "-",
            "0", "C", "=", "+"
        };

        for (String bText : buttons) {
            JButton b = new JButton(bText);
            b.setFont(new Font("Arial", Font.BOLD, 20));
            panel.add(b);

            b.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    String cmd = e.getActionCommand();
                    if (cmd.equals("C")) {
                        display.setText("");
                    } else if (cmd.equals("=")) {
                        try {
                            display.setText("" + eval(display.getText()));
                        } catch (Exception ex) {
                            display.setText("Error");
                        }
                    } else {
                        display.setText(display.getText() + cmd);
                    }
                }
            });
        }

        f.add(panel);
        f.setVisible(true);
    }

    // Evaluates the expression using built-in JavaScript engine (simplifies calculator logic)
    public static double eval(String expr) {
        try {
            return (double) new javax.script.ScriptEngineManager().getEngineByName("JavaScript").eval(expr);
        } catch (Exception e) {
            throw new RuntimeException("Invalid expression");
        }
    }
}
