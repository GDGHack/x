
class Employee{
    private String fname;
    private String lname;
    private double msalary;

    Employee(String fname, String lname, double msalary)
    {
        this.fname=fname;
        this.lname=lname;
       setmsalary(msalary);

    }


    public String getfname()
    {
        return fname;
    }
    public void setfname(String fname)
    {
        this.fname=fname;
    }

    public String getlname()
    {
        return lname;
    }
    public void setlname(String lname)
    {
        this.lname=lname;
    }

    public double getmsalary()
    {
        return msalary;
    }
    public void setmsalary(double msalary)
    {
        if(msalary>0)
        {
            this.msalary=msalary;
        }
        else{
            this.msalary=0;
        }
    }

    public double getysalary()
    {
        return msalary*12;
    }

    public void giveraise()
    {
        this.msalary*=1.10;
    }

    


}

public class emptest
    {
        public static void main(String []args)
        {
            Employee emp1 = new Employee("vishal","wak",50000);
            Employee emp2 = new Employee("anuj","waghmare",40000);


            System.out.println("before increment");
            System.out.println(emp1.getysalary());
            System.out.println(emp2.getysalary());
            emp1.giveraise();
            emp2.giveraise();

            System.out.println(emp1.getysalary());
            System.out.println(emp2.getysalary());
        }
    }