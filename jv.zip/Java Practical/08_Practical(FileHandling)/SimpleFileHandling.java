import java.io.*;
import java.util.Scanner;

public class SimpleFileHandling {

    // Function to read and display content of the file
    public static void readFileContent(File file) {
        try {
            FileReader fr = new FileReader(file);
            BufferedReader br = new BufferedReader(fr);
            String line;
            while ((line = br.readLine()) != null) {
                System.out.println(line);
            }
            br.close();
        } catch (IOException e) {
            System.out.println("An error occurred while reading the file.");
            e.printStackTrace();
        }
    }

    // Function to append data to the file
    public static void appendToFile(File file, Scanner scanner) {
        try {
            System.out.print("Enter the data you want to append: ");
            String dataToAppend = scanner.nextLine();

            FileWriter fw = new FileWriter(file, true);  // 'true' for appending
            BufferedWriter bw = new BufferedWriter(fw);
            bw.write(dataToAppend);
            bw.newLine();  // Add a new line after the data
            bw.close();
            System.out.println("Data appended successfully!");
        } catch (IOException e) {
            System.out.println("An error occurred while appending data.");
            e.printStackTrace();
        }
    }

    // Function to replace text in the file
    public static void replaceTextInFile(File file, Scanner scanner) {
        try {
            System.out.print("Enter the text to be replaced: ");
            String oldText = scanner.nextLine();
            System.out.print("Enter the new text: ");
            String newText = scanner.nextLine();

            FileReader fr = new FileReader(file);
            BufferedReader br = new BufferedReader(fr);
            StringBuilder fileContent = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) {
                fileContent.append(line.replace(oldText, newText)).append("\n");
            }
            br.close();

            // Overwrite the file with the modified content
            FileWriter fw = new FileWriter(file);
            BufferedWriter bw = new BufferedWriter(fw);
            bw.write(fileContent.toString());
            bw.close();
            System.out.println("Text replaced successfully!");
        } catch (IOException e) {
            System.out.println("An error occurred while replacing text.");
            e.printStackTrace();
        }
    }

    // Function to create a new file and write data to it
    public static void createNewFile(File file, Scanner scanner) {
        try {
            if (file.createNewFile()) {
                System.out.println("New file created: " + file.getName());
            } else {
                System.out.println("File already exists!");
            }

            System.out.print("Enter the data to store in the new file: ");
            String data = scanner.nextLine();

            FileWriter fw = new FileWriter(file);
            BufferedWriter bw = new BufferedWriter(fw);
            bw.write(data);
            bw.close();
            System.out.println("Data written to the new file!");
        } catch (IOException e) {
            System.out.println("An error occurred while creating the file.");
            e.printStackTrace();
        }
    }

    // Function to prompt the user for the operation to be performed
    public static int getUserChoice(Scanner scanner) {
        System.out.println("\nWhat would you like to do?");
        System.out.println("1. Add data to the end of the file");
        System.out.println("2. Replace specified text in the file");
        System.out.println("3. Exit the program");
        System.out.print("Enter your choice (1, 2, or 3): ");
        return scanner.nextInt();
    }

    // Main method that drives the program
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.print("Enter the file name: ");
            String fileName = scanner.nextLine();

            File file = new File(fileName);

            // If the file exists, read and display its content
            if (file.exists()) {
                System.out.println("\nFile contents:");
                readFileContent(file);

                // Ask user what action to take
                int choice = getUserChoice(scanner);
                scanner.nextLine();  // Consume the newline character after the integer input

                switch (choice) {
                    case 1:
                        appendToFile(file, scanner);
                        break;

                    case 2:
                        replaceTextInFile(file, scanner);
                        break;

                    case 3:
                        System.out.println("Exiting the program...");
                        scanner.close();
                        return;  // Exit the program

                    default:
                        System.out.println("Invalid choice. Please select 1, 2, or 3.");
                        break;
                }

            } else {
                // If the file doesn't exist, create a new one
                createNewFile(file, scanner);
            }

            // Ask the user if they want to continue or exit
            System.out.print("\nWould you like to continue? (y/n): ");
            String continueChoice = scanner.nextLine();
            if (continueChoice.equalsIgnoreCase("n")) {
                System.out.println("Exiting the program...");
                break;  // Exit the while loop and end the program
            }
        }
    }
}
