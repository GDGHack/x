import java.lang.invoke.StringConcatFactory;
import java.util.*;

interface StackInterface
{
    void push(String item);
    String pop();
    boolean underflow();
    boolean overflow();
    void display();

}

class IntegerStack implements StackInterface{

    private int[] stack;
    private int size;
    private int top;
    public IntegerStack(int size)
    {
        this.size=size;
        top=-1;
        stack= new int[size];
    }

   public  String pop()
    {

        if(underflow())
        {
            System.out.println("no elememts");
            return null;
        }
         else{
            return  Integer.toString(stack[top--]);
         }
    }

    public void push(String item)
    {
        if(overflow())
        {
            System.out.println("no space");
        }
        else{
             int value= Integer.parseInt(item);

            stack[++top]=value;
        }
    }

    public void display()
    {
        if(underflow())
        {
            System.out.println("no elements");
        }
        else{
            for(int i=top; i>=0; i--)
            {
                System.out.println(stack[i]);
            }
        }
    }

    public boolean underflow()
    {
        return top==-1;
    }
    public boolean overflow()
    {
        return top==size-1;
    }



}



class StringStack implements StackInterface{

    private String[] stack;
    private int size;
    private int top;
    public StringStack(int size)
    {
        this.size=size;
        top=-1;
        stack= new String[size];
    }

   public  String pop()
    {

        if(underflow())
        {
            System.out.println("no elememts");
            return null;
        }
         else{
            return  stack[top--];
         }
    }

    public void push(String item)
    {
        if(overflow())
        {
            System.out.println("no space");
        }
        else{
             

            stack[++top]=item;
        }
    }

    public void display()
    {
        if(underflow())
        {
            System.out.println("no elements");
        }
        else{
            for(int i=top; i>=0; i--)
            {
                System.out.println(stack[i]);
            }
        }
    }

    public boolean underflow()
    {
        return top==-1;
    }
    public boolean overflow()
    {
        return top==size-1;
    }



}

public class stack1{
    public static void main(String [] args)
    {
        StackInterface intStack = new IntegerStack(3);
        intStack.push("10");
        intStack.push("20");
        intStack.push("30");
        intStack.push("40"); // Overflow
        intStack.display();
        System.out.println("Popped from IntegerStack: " + intStack.pop());
        intStack.display();

        System.out.println("\n---------------------------\n");


        StackInterface stringstack= new StringStack(2);
        stringstack.push("abcd");
        stringstack.push("karan");
        stringstack.push("amit");

        stringstack.display();
        System.out.println("popped"+stringstack.pop());
        stringstack.display();


    }
}