import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class StudentRegistrationLogin extends JFrame {
    private JTextField usernameField, loginUsernameField;
    private JPasswordField passwordField, loginPasswordField;
    private JButton registerButton, loginButton;
    
    // JDBC connection variables (Oracle)
    private static final String DB_URL = "jdbc:oracle:thin:@localhost:1521:XE"; // Oracle DB connection string (change if needed)
    private static final String DB_USER = "student_user";  // Use your Oracle DB username
    private static final String DB_PASSWORD = "password";  // Use your Oracle DB password

    public StudentRegistrationLogin() {
        setTitle("Student Registration and Login");
        setLayout(new CardLayout());
        
        // Registration Panel
        JPanel registerPanel = new JPanel();
        registerPanel.setLayout(new GridLayout(3, 2));
        
        registerPanel.add(new JLabel("Username:"));
        usernameField = new JTextField();
        registerPanel.add(usernameField);
        
        registerPanel.add(new JLabel("Password:"));
        passwordField = new JPasswordField();
        registerPanel.add(passwordField);
        
        registerButton = new JButton("Register");
        registerButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                registerUser();
            }
        });
        registerPanel.add(registerButton);

        // Login Panel
        JPanel loginPanel = new JPanel();
        loginPanel.setLayout(new GridLayout(3, 2));
        
        loginPanel.add(new JLabel("Username:"));
        loginUsernameField = new JTextField();
        loginPanel.add(loginUsernameField);
        
        loginPanel.add(new JLabel("Password:"));
        loginPasswordField = new JPasswordField();
        loginPanel.add(loginPasswordField);
        
        loginButton = new JButton("Login");
        loginButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                loginUser();
            }
        });
        loginPanel.add(loginButton);

        // Add both panels to the frame
        getContentPane().add(registerPanel, "Register");
        getContentPane().add(loginPanel, "Login");

        // Initial Panel Display
        CardLayout cl = (CardLayout) getContentPane().getLayout();
        cl.show(getContentPane(), "Register");

        setSize(400, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);  // Center the window
        setVisible(true);
    }

    // Register the user into the database
    private void registerUser() {
        String username = usernameField.getText();
        String password = new String(passwordField.getPassword());

        if (username.isEmpty() || password.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill in both fields.");
            return;
        }

        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            String query = "INSERT INTO students (username, password) VALUES (?, ?)";
            try (PreparedStatement ps = conn.prepareStatement(query)) {
                ps.setString(1, username);
                ps.setString(2, password);
                int result = ps.executeUpdate();
                
                if (result > 0) {
                    JOptionPane.showMessageDialog(this, "Registration Successful!");
                    switchToLogin();
                } else {
                    JOptionPane.showMessageDialog(this, "Registration Failed.");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Database error: " + e.getMessage());
        }
    }

    // Log in the user by checking the credentials in the database
    private void loginUser() {
        String username = loginUsernameField.getText();
        String password = new String(loginPasswordField.getPassword());

        if (username.isEmpty() || password.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill in both fields.");
            return;
        }

        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            String query = "SELECT * FROM students WHERE username = ? AND password = ?";
            try (PreparedStatement ps = conn.prepareStatement(query)) {
                ps.setString(1, username);
                ps.setString(2, password);
                ResultSet rs = ps.executeQuery();
                
                if (rs.next()) {
                    JOptionPane.showMessageDialog(this, "Login Successful!");
                } else {
                    JOptionPane.showMessageDialog(this, "Invalid username or password.");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Database error: " + e.getMessage());
        }
    }

    // Switch to the login screen
    private void switchToLogin() {
        CardLayout cl = (CardLayout) getContentPane().getLayout();
        cl.show(getContentPane(), "Login");
    }

    public static void main(String[] args) {
        // Load JDBC driver
        try {
            Class.forName("oracle.jdbc.OracleDriver");
            new StudentRegistrationLogin();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "JDBC Driver not found.");
        }
    }
}
