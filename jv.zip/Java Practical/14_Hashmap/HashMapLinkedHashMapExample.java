import java.util.*;

public class HashMapLinkedHashMapExample {
    public static void main(String[] args) {
        // Step 1: Create and fill a HashMap
        HashMap<Integer, String> hashMap = new HashMap<>();
        hashMap.put(42, "Answer");
        hashMap.put(17, "Seventeen");
        hashMap.put(8, "Eight");
        hashMap.put(99, "Ninety-Nine");

        // Step 2: Print the HashMap (unordered)
        System.out.println("HashMap (unordered):");
        for (Map.Entry<Integer, String> entry : hashMap.entrySet()) {
            System.out.println(entry.getKey() + " => " + entry.getValue());
        }

        // Step 3: Sort by key and insert into LinkedHashMap
        List<Map.Entry<Integer, String>> sortedEntries = new ArrayList<>(hashMap.entrySet());
        sortedEntries.sort(Map.Entry.comparingByKey());

        LinkedHashMap<Integer, String> linkedHashMap = new LinkedHashMap<>();
        for (Map.Entry<Integer, String> entry : sortedEntries) {
            linkedHashMap.put(entry.getKey(), entry.getValue());
        }

        // Step 4: Print the LinkedHashMap (insertion order = sorted order)
        System.out.println("\nLinkedHashMap (sorted by key, insertion order preserved):");
        for (Map.Entry<Integer, String> entry : linkedHashMap.entrySet()) {
            System.out.println(entry.getKey() + " => " + entry.getValue());
        }
    }
}
