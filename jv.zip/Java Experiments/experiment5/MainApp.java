import java.util.Scanner;
import math.Statistics;
import math.convert.DecimalConverter;


public class MainApp {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter number of elements: ");
        int size = sc.nextInt();
        double[] data = new double[size];

        System.out.println("Enter the numbers:");
        for (int i = 0; i < size; i++) {
            data[i] = sc.nextDouble();
        }

        System.out.println("\n--- Statistics ---");
        System.out.println("Mean: " + Statistics.mean(data));
        System.out.println("Median: " + Statistics.median(data));
        System.out.println("Standard Deviation: " + Statistics.standardDeviation(data));

        System.out.print("\nEnter a decimal number: ");
        int num = sc.nextInt();

        System.out.println("Binary: " + DecimalConverter.toBinary(num));
        System.out.println("Octal: " + DecimalConverter.toOctal(num));
        System.out.println("Hex: " + DecimalConverter.toHex(num));

       

        sc.close();
    }
}
