import java.io.*;
import java.util.LinkedList;

public class ReverseFileReader {

    public static void main(String[] args) {
        // Corrected file path with escaped backslashes
        String fileName = "C:\\Users\\wakar\\OneDrive\\Desktop\\java\\experiment13\\abcd.txt.txt";  // Change this to your file's path

        // LinkedList to store the lines of the file
        LinkedList<String> lines = new LinkedList<>();

        // Read the file and add each line to the LinkedList
        try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
            String line;
            while ((line = reader.readLine()) != null) {
                lines.add(line);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        // Print the lines in reverse order
        System.out.println("Lines in reverse order:");
        for (int i = lines.size() - 1; i >= 0; i--) {
            System.out.println(lines.get(i));
        }
    }
}
