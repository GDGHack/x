// Abstract Class Shape
abstract class Shape {
    double side;
    double area;
    double perimeter;

    Shape(double side) {
        this.side = side;
    }

    abstract void calculateArea();
    abstract void calculatePerimeter();


    // Concerete function remains same for all subclasses

    void display() {
        System.out.println("Area: " + area);
        System.out.println("Perimeter: " + perimeter);
    }
}

// Triangle subclass
class Triangle extends Shape {
    double height;

    Triangle(double base, double height) {
        super(base); // Here super calls the parent constructor
        this.height = height;
    }

    @Override
    void calculateArea() {
        area = (side * height) / 2;
    }

    @Override
    void calculatePerimeter() {
        perimeter = 3 * side; // Assuming equilateral triangle
    }

    @Override
    void display() {
        System.out.println("Triangle:");
        super.display(); // Access parent class function
    }
}

// Rectangle subclass
class Rectangle extends Shape {
    double width;

    Rectangle(double length, double width) {
        super(length);
        this.width = width;
    }

    @Override
    void calculateArea() {
        area = side * width;
    }

    @Override
    void calculatePerimeter() {
        perimeter = 2 * (side + width);
    }

    @Override
    void display() {
        System.out.println("Rectangle:");
        super.display();
    }
}

// Circle subclass
class Circle extends Shape {
    Circle(double radius) {
        super(radius);
    }

    @Override
    void calculateArea() {
        area = Math.PI * side * side; // side is radius
    }

    @Override
    void calculatePerimeter() {
        perimeter = 2 * Math.PI * side;
    }

    @Override
    void display() {
        System.out.println("Circle:");
        super.display();
    }
}

// Cube subclass
class Cube extends Shape {
    Cube(double side) {
        super(side);
    }

    @Override
    void calculateArea() {
        area = 6 * side * side; // Surface area
    }

    @Override
    void calculatePerimeter() {
        perimeter = 12 * side; // Sum of all edges
    }

    @Override
    void display() {
        System.out.println("Cube:");
        super.display();
    }
}

// Square subclass
class Square extends Shape {
    Square(double side) {
        super(side);
    }

    @Override
    void calculateArea() {
        area = side * side;
    }

    @Override
    void calculatePerimeter() {
        perimeter = 4 * side;
    }

    @Override
    void display() {
        System.out.println("Square:");
        super.display();
    }
}

// Test class
public class ShapeTest {
    public static void main(String[] args) {
        Shape s;

        s = new Triangle(5, 4);
        s.calculateArea();
        s.calculatePerimeter();
        s.display();

        s = new Rectangle(5, 3);
        s.calculateArea();
        s.calculatePerimeter();
        s.display();

        s = new Circle(7);
        s.calculateArea();
        s.calculatePerimeter();
        s.display();

        s = new Cube(4);
        s.calculateArea();
        s.calculatePerimeter();
        s.display();

        s = new Square(6);
        s.calculateArea();
        s.calculatePerimeter();
        s.display();
    }
}
