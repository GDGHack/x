class LowBalanceException extends Exception {
    LowBalanceException(String message) {
        super(message);
    }
}

class NegativeNumberException extends Exception {
    NegativeNumberException(String message) {
        super(message);
    }
}

class PasswordMismatchException extends Exception {
    PasswordMismatchException(String message) {
        super(message);
    }
}

public class Bank {
    String name;
    double balance;
    String password;

    Bank(String name, double balance, String password) {
        this.name = name;
        this.balance = balance;
        this.password = password;
    }

    void balanceEnquiry() {
        System.out.println(name + "'s Balance: ₹" + balance);
    }

    void deposit(double amount) throws NegativeNumberException {
        if (amount < 0) {
            throw new NegativeNumberException("Not entered a valid number.");
        }
        balance += amount;
        System.out.println("₹" + amount + " deposited successfully to " + name + "'s account. New balance: ₹" + balance);
    }

    void withdraw(double amount) throws LowBalanceException {
        if (balance < amount) {
            throw new LowBalanceException("Insufficient balance.");
        }
        balance -= amount;
        System.out.println("₹" + amount + " withdrawn successfully from " + name + "'s account. New balance: ₹" + balance);
    }

    void transfer(Bank receiver, double amount) throws LowBalanceException, NegativeNumberException {
        this.withdraw(amount);           // Withdraw from sender
        receiver.deposit(amount);        // Deposit to receiver
        System.out.println("₹" + amount + " transferred from " + name + " to " + receiver.name);
    }

    // Main method
    public static void main(String[] args) {
        Bank[] accounts = new Bank[2];

        try {
            accounts[0] = new Bank("Vishal", 3000, "abc");
            accounts[1] = new Bank("Anuj", 2000, "hii");

            accounts[0].deposit(200);
            accounts[1].deposit(300);

            accounts[0].withdraw(150);

            accounts[0].balanceEnquiry();
            accounts[1].balanceEnquiry();

            accounts[0].transfer(accounts[1], 250);

            accounts[0].balanceEnquiry();
            accounts[1].balanceEnquiry();

        } catch (LowBalanceException | NegativeNumberException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}
