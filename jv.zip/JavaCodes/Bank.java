class LowBalanceException extends Exception {
	LowBalanceException(String message) {
		super(message);
	}
}

class NegativeNumberException extends Exception {
	NegativeNumberException(String message) {
		super(message);
	}
}

class PasswordMismatchException extends Exception {
	PasswordMismatchException(String message) {
		super(message);
	}
}

public class Bank {
	String name;
	double balance;
	String password;
	
	Bank(String name, double balance, String password) {
		this.name = name;
		this.balance = balance;
		this.password = password;
	}
	
	void getBal() {
		System.out.println(name + "\nBalance : " + balance);
	}
	
	void deposit(double amount) throws NegativeNumberException {
		if (amount < 0) {
			throw new NegativeNumberException("Number Should not be Negative");
		} else {
			balance += amount;
			System.out.println("Rs." + amount + "deposited to the account.");
		}
	}
	
	void withdraw(double amount) throws LowBalanceException {
		if(balance < amount) {
			throw new LowBalanceException("Balance is lesser Than the amount");
		} else {
			balance -= amount;
			System.out.println("Rs." + amount + "withdrawn from the account.");
		}
	}
	
	void transfer(Bank receiver, double amount) throws NegativeNumberException, LowBalanceException {
		this.withdraw(amount);
		receiver.deposit(amount);
		System.out.println("Transaction Completed !");
	}
	
	public static void main(String[] args) {
		Bank[] accounts = new Bank[2];
		
		try {
			accounts[0] = new Bank("Avishkar", 3000, "abc");
            accounts[1] = new Bank("Anuj", 2000, "abc");

            accounts[0].deposit(200);
            accounts[1].deposit(300);

            accounts[0].withdraw(150);

            accounts[0].getBal();
            accounts[1].getBal();

            accounts[0].transfer(accounts[1], 250);

            accounts[0].getBal();
            accounts[1].getBal();		
		} catch (NegativeNumberException | LowBalanceException e) {
			System.out.println(e.getMessage());
		}
	}
		
}		