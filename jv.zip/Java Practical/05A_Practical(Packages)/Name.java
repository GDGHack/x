package Package1;

import java.util.*;

public class Name {
    public void userName(String name){
        System.out.println("Hello My Name is " + name);
    }
    public static void main(String[] args){
        Name name = new Name();
        Scanner sc = new Scanner(System.in);
        String username = sc.nextLine();
        name.userName(username);
    }
}
