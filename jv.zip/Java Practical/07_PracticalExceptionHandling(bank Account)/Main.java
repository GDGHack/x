// Custom Exception for Low Balance
class LowBalanceException extends Exception {
    public LowBalanceException(String message) {
        super(message); // Pass message to the parent Exception class
    }
}

// Custom Exception for Negative Amount (for deposit/withdrawal)
class NegativeAmountException extends Exception {
    public NegativeAmountException(String message) {
        super(message);
    }
}

// Custom Exception for Incorrect Password
class IncorrectPasswordException extends Exception {
    public IncorrectPasswordException(String message) {
        super(message);
    }
}

// BankAccount Class that models a simple bank account
class BankAccount {
    private String accountHolderName;  // Name of the account holder
    private double balance;  // Current balance in the account
    private String password;  // Password for the account

    // Constructor to initialize the bank account
    public BankAccount(String accountHolderName, double initialBalance, String password) {
        this.accountHolderName = accountHolderName;
        this.balance = initialBalance;
        this.password = password;
    }

    // Method to check balance with password verification
    public double checkBalance(String password) throws IncorrectPasswordException {
        if (!this.password.equals(password)) {
            throw new IncorrectPasswordException("Password is incorrect.");
        }
        return this.balance;  // Return the balance if password is correct
    }

    // Method to deposit money into the account
    public void deposit(double amount) throws NegativeAmountException {
        if (amount < 0) {
            throw new NegativeAmountException("Deposit amount cannot be negative.");
        }
        this.balance += amount;  // Add the deposit amount to the balance
        System.out.println("Deposited: " + amount + ". New Balance: " + this.balance);
    }

    // Method to withdraw money from the account with password verification
    public void withdraw(double amount, String password) throws LowBalanceException, NegativeAmountException, IncorrectPasswordException {
        if (!this.password.equals(password)) {
            throw new IncorrectPasswordException("Password is incorrect.");
        }
        if (amount < 0) {
            throw new NegativeAmountException("Withdrawal amount cannot be negative.");
        }
        if (this.balance < amount) {
            throw new LowBalanceException("Insufficient balance to withdraw.");
        }
        this.balance -= amount;  // Deduct the amount from the balance
        System.out.println("Withdrew: " + amount + ". New Balance: " + this.balance);
    }

    // Method to transfer money from one account to another
    public void transfer(double amount, BankAccount targetAccount, String password) throws LowBalanceException, NegativeAmountException, IncorrectPasswordException {
        if (!this.password.equals(password)) {
            throw new IncorrectPasswordException("Password is incorrect.");
        }
        if (amount < 0) {
            throw new NegativeAmountException("Transfer amount cannot be negative.");
        }
        if (this.balance < amount) {
            throw new LowBalanceException("Insufficient balance to transfer.");
        }

        // Deduct the amount from this account
        this.balance -= amount;
        System.out.println("Transferred: " + amount + " from your account.");

        // Add the amount to the target account
        targetAccount.balance += amount;
        System.out.println("Transferred: " + amount + " to the target account. Target Balance: " + targetAccount.balance);
    }
}

public class Main {
    public static void main(String[] args) {
        // Creating two bank accounts for Akash and Amit
        BankAccount akashAccount = new BankAccount("Akash", 1000, "password123");
        BankAccount amitAccount = new BankAccount("Amit", 500, "password456");

        try {
            // Checking initial balances
            System.out.println("Akash's Balance: " + akashAccount.checkBalance("password123"));
            System.out.println("Amit's Balance: " + amitAccount.checkBalance("password456"));

            // Depositing money into Akash's and Amit's accounts
            akashAccount.deposit(500);  // Akash deposits 500
            amitAccount.deposit(200);    // Amit deposits 200

            // Withdrawing money from Akash's and Amit's accounts
            akashAccount.withdraw(200, "password123");  // Akash withdraws 200
            amitAccount.withdraw(100, "password456");    // Amit withdraws 100

            // Transferring money from Akash to Amit
            akashAccount.transfer(300, amitAccount, "password123");  // Akash transfers 300 to Amit

            // Checking balances after all transactions
            System.out.println("Akash's Balance after transactions: " + akashAccount.checkBalance("password123"));
            System.out.println("Amit's Balance after transactions: " + amitAccount.checkBalance("password456"));

        } catch (LowBalanceException | NegativeAmountException | IncorrectPasswordException e) {
            // Catch and print error messages
            System.out.println("Error: " + e.getMessage());
        }
    }
}
