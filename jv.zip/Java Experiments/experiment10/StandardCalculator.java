import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Stack;

public class StandardCalculator extends JFrame {

    private JTextField displayField;  // Display area for the calculator
    private String currentExpression; // Store the current expression

    public StandardCalculator() {
        setTitle("Calculator");
        setSize(350, 500);  // Small, mobile-like size
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);  // Center the window on the screen

        currentExpression = "";  // Initialize the expression

        displayField = new JTextField();
        displayField.setEditable(false);
        displayField.setFont(new Font("Arial", Font.PLAIN, 28));
        displayField.setBackground(Color.BLACK);
        displayField.setForeground(Color.WHITE);
        displayField.setHorizontalAlignment(JTextField.RIGHT);
        displayField.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));

        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BorderLayout());

        // Title Label at the top of the calculator
        JLabel titleLabel = new JLabel("Calculator", JLabel.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        titleLabel.setBackground(Color.GRAY);
        titleLabel.setOpaque(true);
        mainPanel.add(titleLabel, BorderLayout.NORTH);

        mainPanel.add(displayField, BorderLayout.CENTER);

        // Button panel
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new GridLayout(5, 4, 10, 10));
        addButtons(buttonPanel);

        mainPanel.add(buttonPanel, BorderLayout.SOUTH);
        add(mainPanel);

        setVisible(true);  // Display the frame
    }

    private void addButtons(JPanel panel) {
        String[] buttons = {
                "7", "8", "9", "/",
                "4", "5", "6", "*",
                "1", "2", "3", "-",
                "0", ".", "=", "+",
                "C", "AC"
        };

        // Add buttons to the panel
        for (String text : buttons) {
            JButton button = new JButton(text);
            button.setFont(new Font("Arial", Font.PLAIN, 24));
            button.addActionListener(new ButtonClickListener());
            panel.add(button);
        }
    }

    private class ButtonClickListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            String command = e.getActionCommand();

            // Handle button clicks
            if (command.equals("C")) {
                if (currentExpression.length() > 0) {
                    // Remove last character
                    currentExpression = currentExpression.substring(0, currentExpression.length() - 1);
                    displayField.setText(currentExpression);
                }
            } else if (command.equals("AC")) {
                // Clear all
                currentExpression = "";
                displayField.setText("");
            } else if (command.equals("=")) {
                // Evaluate the expression and show the result
                if (!currentExpression.isEmpty()) {
                    try {
                        // Check if expression ends with an operator
                        if (currentExpression.length() > 0 && isOperator(currentExpression.charAt(currentExpression.length() - 1))) {
                            displayField.setText("Invalid Input");
                            return;
                        }

                        double result = evaluateExpression(currentExpression);
                        if (Double.isNaN(result) || Double.isInfinite(result)) {
                            displayField.setText("Error");
                            currentExpression = "";
                        } else {
                            // Format the result to avoid unnecessary decimal places
                            String resultStr = (result == (long) result) ? 
                                String.valueOf((long) result) : String.valueOf(result);
                            displayField.setText(resultStr);
                            currentExpression = resultStr;  // Store the result for further calculations
                        }
                    } catch (Exception ex) {
                        displayField.setText("Invalid Input");
                        currentExpression = "";
                    }
                }
            } else {
                // Check if we're trying to add multiple operators in a row
                if (isOperator(command.charAt(0)) && currentExpression.length() > 0 && 
                    isOperator(currentExpression.charAt(currentExpression.length() - 1))) {
                    // Replace the last operator
                    currentExpression = currentExpression.substring(0, currentExpression.length() - 1) + command;
                } else {
                    // Append the clicked button's value to the expression
                    currentExpression += command;
                }
                displayField.setText(currentExpression);
            }
        }
    }

    // Check if a character is an operator (+, -, *, /)
    private boolean isOperator(char c) {
        return c == '+' || c == '-' || c == '*' || c == '/';
    }

    // Custom method to evaluate the expression
    private double evaluateExpression(String expression) {
        try {
            return new ExpressionEvaluator().evaluate(expression);
        } catch (Exception e) {
            return Double.NaN;
        }
    }

    // Inner class to evaluate mathematical expressions
    private class ExpressionEvaluator {
        public double evaluate(String expression) {
            // Remove all spaces
            expression = expression.replaceAll("\\s+", "");
            
            return evaluateExpression(expression, 0, expression.length());
        }

        private double evaluateExpression(String expression, int start, int end) {
            // Basic recursive descent parser for mathematical expressions
            Stack<Double> values = new Stack<>();
            Stack<Character> operators = new Stack<>();
            
            for (int i = start; i < end; i++) {
                char c = expression.charAt(i);
                
                // Skip spaces
                if (c == ' ') continue;
                
                // Handle numbers (could be multi-digit or decimal)
                if (Character.isDigit(c) || c == '.') {
                    StringBuilder numBuilder = new StringBuilder();
                    // Read the entire number
                    while (i < end && (Character.isDigit(expression.charAt(i)) || expression.charAt(i) == '.')) {
                        numBuilder.append(expression.charAt(i++));
                    }
                    i--; // Adjust index since the for loop will increment it
                    values.push(Double.parseDouble(numBuilder.toString()));
                } 
                // Handle operators
                else if (isOperator(c)) {
                    // While top of 'operators' has same or greater precedence to current
                    // operator, process it
                    while (!operators.isEmpty() && hasPrecedence(c, operators.peek())) {
                        values.push(applyOperation(operators.pop(), values.pop(), values.pop()));
                    }
                    // Push current operator to 'operators'
                    operators.push(c);
                }
            }
            
            // Process remaining operators
            while (!operators.isEmpty()) {
                values.push(applyOperation(operators.pop(), values.pop(), values.pop()));
            }
            
            // The final result should be the only value in the stack
            return values.pop();
        }
        
        private boolean hasPrecedence(char op1, char op2) {
            if ((op1 == '*' || op1 == '/') && (op2 == '+' || op2 == '-')) {
                return false;
            }
            return true;
        }
        
        private double applyOperation(char operator, double b, double a) {
            switch (operator) {
                case '+': return a + b;
                case '-': return a - b;
                case '*': return a * b;
                case '/': 
                    if (b == 0) throw new ArithmeticException("Division by zero");
                    return a / b;
            }
            return 0;
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new StandardCalculator());
    }
}