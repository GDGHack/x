// File: Main.java
import stats.StatisticsCalculator;  // Correct package import
import java.util.Scanner;
public class Main {

    public static void main(String[] args) {
        // Test data
        //int[] numbers = {1, 2, 2, 3, 4, 5, 6, 6, 7};
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter the size of a Data :");
        int n = sc.nextInt();

        int[] numbers = new int[n];
        System.out.print("Enter the Data :");
        for(int i = 0; i < n; i++){
            numbers[i] = sc.nextInt();
        }
        // Calculate Mean
        StatisticsCalculator obj = new StatisticsCalculator();
        double mean = obj.mean(numbers);
        System.out.println("Mean: " + mean);

        // Calculate Mode
        int mode = obj.mode(numbers);
        System.out.println("Mode: " + mode);

        // Calculate Median
        double median = obj.median(numbers);
        System.out.println("Median: " + median);
        // Calculate standard deviation
        double std = obj.standardDeviation(numbers);
        System.out.println("Median: " + std);
    }
}
