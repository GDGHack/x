// mkdir -p out
// javac -d out EXP_05.java math/Stats.java
// jar cvfm MyJar.jar manifest.txt -C out .
// java -jar MyJar.jar

// Manifest-Version: 1.0
// Main-Class: EXP_05

import java.util.Scanner;
import math.Stats;

public class EXP_05 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		System.out.print("Enter number of elements: ");
        int size = sc.nextInt();
        double[] data = new double[size];

        System.out.println("Enter the numbers:");
        for (int i = 0; i < size; i++) {
            data[i] = sc.nextDouble();
        }

        System.out.println("\n--- Statistics ---");
        System.out.println("Mean: " + Stats.mean(data));
        System.out.println("Median: " + Stats.median(data));
        System.out.println("Standard Deviation: " + Stats.standardDeviation(data));
	}
}