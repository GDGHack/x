import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

public class StopwatchWithLaps extends JFrame {
    private JLabel timeLabel;
    private JButton startButton, stopButton, resetButton, lapButton;
    private DefaultListModel<String> lapListModel;
    private JList<String> lapList;

    private long startTime = 0;
    private long elapsedTime = 0;
    private boolean running = false;
    private Thread timerThread;

    public StopwatchWithLaps() {
        super("Stopwatch with Lap Counter");

        // GUI Layout
        timeLabel = new JLabel("00:00:00.000", SwingConstants.CENTER);
        timeLabel.setFont(new Font("Monospaced", Font.BOLD, 36));

        startButton = new JButton("Start");
        stopButton = new JButton("Stop");
        resetButton = new JButton("Reset");
        lapButton = new JButton("Lap");

        lapListModel = new DefaultListModel<>();
        lapList = new JList<>(lapListModel);

        JPanel buttonPanel = new JPanel();
        buttonPanel.add(startButton);
        buttonPanel.add(stopButton);
        buttonPanel.add(resetButton);
        buttonPanel.add(lapButton);

        JScrollPane lapScrollPane = new JScrollPane(lapList);
        lapScrollPane.setPreferredSize(new Dimension(200, 200));

        // Add to frame
        setLayout(new BorderLayout());
        add(timeLabel, BorderLayout.NORTH);
        add(buttonPanel, BorderLayout.CENTER);
        add(lapScrollPane, BorderLayout.SOUTH);

        // Button Actions
        startButton.addActionListener(e -> start());
        stopButton.addActionListener(e -> stop());
        resetButton.addActionListener(e -> reset());
        lapButton.addActionListener(e -> recordLap());

        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(300, 400);
        setLocationRelativeTo(null);
        setVisible(true);
    }

    private void start() {
        if (running) return;
        running = true;
        startTime = System.currentTimeMillis() - elapsedTime;

        timerThread = new Thread(() -> {
            while (running) {
                elapsedTime = System.currentTimeMillis() - startTime;
                SwingUtilities.invokeLater(() -> timeLabel.setText(formatTime(elapsedTime)));
                try {
                    Thread.sleep(10);
                } catch (InterruptedException ignored) {}
            }
        });
        timerThread.start();
    }

    private void stop() {
        running = false;
    }

    private void reset() {
        stop();
        elapsedTime = 0;
        timeLabel.setText("00:00:00.000");
        lapListModel.clear();
    }

    private void recordLap() {
        if (!running) return;
        String lapTime = formatTime(elapsedTime);
        lapListModel.addElement("Lap " + (lapListModel.size() + 1) + ": " + lapTime);
    }

    private String formatTime(long millis) {
        long hours = millis / 3600000;
        long minutes = (millis % 3600000) / 60000;
        long seconds = (millis % 60000) / 1000;
        long ms = millis % 1000;
        return String.format("%02d:%02d:%02d.%03d", hours, minutes, seconds, ms);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(StopwatchWithLaps::new);
    }
}
