import java.lang.Math;
import java.util.Scanner;

abstract class Shape {
    abstract double calculateArea();
    abstract double calculatePerimeter();
    abstract void display();
}

class Square extends Shape {
    private double side;

    public Square(double side) {
        this.side = side;
    }

    public double calculateArea() {
        return side * side;
    }

    public double calculatePerimeter() {
        return 4 * side; // Perimeter of square is 4 times the side
    }

    public void display() {
        System.out.println("Area of Square: " + calculateArea());
        System.out.println("Perimeter of Square: " + calculatePerimeter());
    }
}

class Rectangle extends Shape {
    private double length;
    private double width;

    public Rectangle(double length, double width) {
        this.length = length;
        this.width = width;
    }

    public double calculateArea() {
        return length * width;
    }

    public double calculatePerimeter() {
        return 2 * (length + width); // Perimeter of rectangle is 2*(length + width)
    }

    public void display() {
        System.out.println("Area of Rectangle: " + calculateArea());
        System.out.println("Perimeter of Rectangle: " + calculatePerimeter());
    }
}

class Triangle extends Shape {
    private double base;
    private double height;
    private double side1;
    private double side2;

    public Triangle(double base, double height, double side1, double side2) {
        this.base = base;
        this.height = height;
        this.side1 = side1;
        this.side2 = side2;
    }

    public double calculateArea() {
        return 0.5 * base * height;
    }

    public double calculatePerimeter() {
        return base + side1 + side2; // Perimeter of triangle is sum of all sides
    }

    public void display() {
        System.out.println("Area of Triangle: " + calculateArea());
        System.out.println("Perimeter of Triangle: " + calculatePerimeter());
    }
}

class Circle extends Shape {
    private double radius;

    public Circle(double radius) {
        this.radius = radius;
    }

    public double calculateArea() {
        return Math.PI * radius * radius;
    }

    public double calculatePerimeter() {
        return 2 * Math.PI * radius; // Perimeter (circumference) of circle is 2πr
    }

    public void display() {
        System.out.println("Area of Circle: " + calculateArea());
        System.out.println("Perimeter (Circumference) of Circle: " + calculatePerimeter());
    }
}

class Cube extends Shape {
    private double side;

    public Cube(double side) {
        this.side = side;
    }

    public double calculateArea() {
        return 6 * side * side; // Surface area of the cube (6 * side^2)
    }

    public double calculatePerimeter() {
        return 12 * side; // Perimeter of a cube is sum of all edges (12 * side)
    }

    public void display() {
        System.out.println("Surface Area of Cube: " + calculateArea());
        System.out.println("Perimeter of Cube: " + calculatePerimeter());
    }
}

class Cone extends Shape {
    private double radius;
    private double height;

    public Cone(double radius, double height) {
        this.radius = radius;
        this.height = height;
    }

    public double calculateArea() {
        double slantHeight = Math.sqrt(radius * radius + height * height); // Using Pythagoras theorem for slant height
        return Math.PI * radius * (radius + slantHeight); // Surface area of the cone
    }

    public double calculatePerimeter() {
        return 2 * Math.PI * radius; // Circumference of the base of the cone
    }

    public void display() {
        System.out.println("Surface Area of Cone: " + calculateArea());
        System.out.println("Perimeter (Circumference of base) of Cone: " + calculatePerimeter());
    }
}

public class ShapeTest {
    public static void main(String[] args) {
        System.out.println("Enter The Side of Square : ");
        Scanner sc = new Scanner(System.in);
        double side = sc.nextDouble();
        Shape square = new Square(side);

        System.out.println("Enter The length of rectangle : ");
        double length = sc.nextDouble();
        System.out.println("Enter The width of rectangle : ");
        double width = sc.nextDouble();
        Shape rectangle = new Rectangle(length, width);

        System.out.println("Enter The base of triangle : ");
        double base = sc.nextDouble();
        System.out.println("Enter The height of triangle : ");
        double height = sc.nextDouble();
        System.out.println("Enter The side1 of triangle : ");
        double side1 = sc.nextDouble();
        System.out.println("Enter The side2 of triangle : ");
        double side2 = sc.nextDouble();
        Shape triangle = new Triangle(base, height, side1, side2); // base, height, side1, side2

        System.out.println("Enter The radius of circle : ");
        Shape circle = new Circle(5);
        Shape cube = new Cube(3);
        Shape cone = new Cone(3, 4);

        square.display();
        rectangle.display();
        triangle.display();
        circle.display();
        cube.display();
        cone.display();
        sc.close();
    }
}
