class SavingAccount {
	private static double airate;
	private double sbalance;
	
	SavingAccount(double sbalance) {
		this.sbalance = sbalance;
	}
	
	public double calairate() {
		double interest = (sbalance * airate) / 12;
		sbalance += interest;
		return sbalance;
	}
	
	public static void modifyairate(double newairate) {
		airate = newairate / 100;
	}
	
	public double getbal() {
		return sbalance;
	}
}

public class EXP_02 {
    public static void main(String[] args) {
        SavingAccount obj1 = new SavingAccount(2000);
        SavingAccount obj2 = new SavingAccount(3000);

        System.out.println("Initial Balance:");
        System.out.println(obj1.getbal());
        System.out.println(obj2.getbal());

        System.out.println("\nAfter modifying annual interest rate to 4%:");
        SavingAccount.modifyairate(4);
        System.out.println(obj1.calairate());
        System.out.println(obj2.calairate());

        System.out.println("\nAfter modifying annual interest rate to 5%:");
        SavingAccount.modifyairate(5);
        System.out.println(obj1.calairate());
        System.out.println(obj2.calairate());
    }
}
