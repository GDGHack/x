import java.util.Scanner;

interface QueueOperations {
    void enqueue(int item);
    void enqueue(double item);
    void enqueue(String item);
    int dequeue();
    double dequeueDouble();
    String dequeueString();
    int peek();
    double peekDouble();
    String peekString();
    boolean isEmpty();
}

class IntegerQueue implements QueueOperations {
    private int[] queueArray;
    private int front;
    private int rear;
    private int capacity;

    public IntegerQueue(int capacity) {
        this.capacity = capacity;
        this.queueArray = new int[capacity];
        this.front = -1;
        this.rear = -1;
    }

    public void enqueue(int item) {
        if (rear == capacity - 1) {
            System.out.println("Queue is full!");
        } else {
            if (front == -1) {
                front = 0;
            }
            queueArray[++rear] = item;
            System.out.println(item + " enqueued to queue.");
        }
    }

    public int dequeue() {
        if (isEmpty()) {
            System.out.println("Queue is empty!");
            return -1;
        } else {
            int item = queueArray[front];
            if (front == rear) {
                front = rear = -1;
            } else {
                front++;
            }
            return item;
        }
    }

    public int peek() {
        if (isEmpty()) {
            System.out.println("Queue is empty!");
            return -1;
        } else {
            return queueArray[front];
        }
    }

    public boolean isEmpty() {
        return front == -1;
    }

    public void enqueue(double item) {
    }

    public void enqueue(String item) {
    }

    public double dequeueDouble() {
        return 0;
    }

    public String dequeueString() {
        return null;
    }

    public double peekDouble() {
        return 0;
    }

    public String peekString() {
        return null;
    }
}

class DoubleQueue implements QueueOperations {
    private double[] queueArray;
    private int front;
    private int rear;
    private int capacity;

    public DoubleQueue(int capacity) {
        this.capacity = capacity;
        this.queueArray = new double[capacity];
        this.front = -1;
        this.rear = -1;
    }

    public void enqueue(double item) {
        if (rear == capacity - 1) {
            System.out.println("Queue is full!");
        } else {
            if (front == -1) {
                front = 0;
            }
            queueArray[++rear] = item;
            System.out.println(item + " enqueued to queue.");
        }
    }

    public double dequeueDouble() {
        if (isEmpty()) {
            System.out.println("Queue is empty!");
            return -1;
        } else {
            double item = queueArray[front];
            if (front == rear) {
                front = rear = -1;
            } else {
                front++;
            }
            return item;
        }
    }

    public double peekDouble() {
        if (isEmpty()) {
            System.out.println("Queue is empty!");
            return -1;
        } else {
            return queueArray[front];
        }
    }

    public boolean isEmpty() {
        return front == -1;
    }

    public void enqueue(int item) {
    }

    public void enqueue(String item) {
    }

    public int dequeue() {
        return 0;
    }

    public String dequeueString() {
        return null;
    }

    public int peek() {
        return 0;
    }

    public String peekString() {
        return null;
    }
}

class StringQueue implements QueueOperations {
    private String[] queueArray;
    private int front;
    private int rear;
    private int capacity;

    public StringQueue(int capacity) {
        this.capacity = capacity;
        this.queueArray = new String[capacity];
        this.front = -1;
        this.rear = -1;
    }

    public void enqueue(String item) {
        if (rear == capacity - 1) {
            System.out.println("Queue is full!");
        } else {
            if (front == -1) {
                front = 0;
            }
            queueArray[++rear] = item;
            System.out.println(item + " enqueued to queue.");
        }
    }

    public String dequeueString() {
        if (isEmpty()) {
            System.out.println("Queue is empty!");
            return null;
        } else {
            String item = queueArray[front];
            if (front == rear) {
                front = rear = -1;
            } else {
                front++;
            }
            return item;
        }
    }

    public String peekString() {
        if (isEmpty()) {
            System.out.println("Queue is empty!");
            return null;
        } else {
            return queueArray[front];
        }
    }

    public boolean isEmpty() {
        return front == -1;
    }

    public void enqueue(int item) {
    }

    public void enqueue(double item) {
    }

    public int dequeue() {
        return 0;
    }

    public double dequeueDouble() {
        return 0;
    }

    public int peek() {
        return 0;
    }

    public double peekDouble() {
        return 0;
    }
}

public class QueueProgram {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Choose the type of queue:");
        System.out.println("1. Integer Queue");
        System.out.println("2. Double Queue");
        System.out.println("3. String Queue");

        int choice = scanner.nextInt();
        System.out.print("Enter the size of the queue: ");
        int size = scanner.nextInt();

        QueueOperations queue = null; 

        switch (choice) {
            case 1:
                queue = new IntegerQueue(size);
                break;
            case 2:
                queue = new DoubleQueue(size);
                break;
            case 3:
                queue = new StringQueue(size);
                break;
            default:
                System.out.println("Invalid choice.");
                return;
        }

        while (true) {
            System.out.println("\nChoose an operation:");
            System.out.println("1. Enqueue");
            System.out.println("2. Dequeue");
            System.out.println("3. Peek");
            System.out.println("4. Check if queue is empty");
            System.out.println("5. Exit");

            int operation = scanner.nextInt();

            switch (operation) {
                case 1:
                    if (queue instanceof IntegerQueue) {
                        System.out.print("Enter an integer: ");
                        int intValue = scanner.nextInt();
                        ((IntegerQueue) queue).enqueue(intValue);
                    } else if (queue instanceof DoubleQueue) {
                        System.out.print("Enter a double: ");
                        double doubleValue = scanner.nextDouble();
                        ((DoubleQueue) queue).enqueue(doubleValue);
                    } else if (queue instanceof StringQueue) {
                        System.out.print("Enter a string: ");
                        scanner.nextLine();
                        String stringValue = scanner.nextLine();
                        ((StringQueue) queue).enqueue(stringValue);
                    }
                    break;

                case 2:
                    if (queue instanceof IntegerQueue) {
                        System.out.println("Dequeued: " + ((IntegerQueue) queue).dequeue());
                    } else if (queue instanceof DoubleQueue) {
                        System.out.println("Dequeued: " + ((DoubleQueue) queue).dequeueDouble());
                    } else if (queue instanceof StringQueue) {
                        System.out.println("Dequeued: " + ((StringQueue) queue).dequeueString());
                    }
                    break;

                case 3:
                    if (queue instanceof IntegerQueue) {
                        System.out.println("Front item: " + ((IntegerQueue) queue).peek());
                    } else if (queue instanceof DoubleQueue) {
                        System.out.println("Front item: " + ((DoubleQueue) queue).peekDouble());
                    } else if (queue instanceof StringQueue) {
                        System.out.println("Front item: " + ((StringQueue) queue).peekString());
                    }
                    break;

                case 4:
                    System.out.println("Is queue empty? " + queue.isEmpty());
                    break;

                case 5:
                    System.out.println("Exiting...");
                    return;

                default:
                    System.out.println("Invalid operation!");
            }
        }
    }
}
