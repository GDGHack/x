import java.util.Scanner;

public class Person {
    // Instance variables
    private String name;
    private int age;

    // Constructor
    public Person(String name, int age) {
        this.name = name;
        this.age = age;
    }

    // Getter for name
    public String getName() {
        return name;
    }

    // Setter for name
    public void setName(String name) {
        this.name = name;
    }

    // Getter for age
    public int getAge() {
        return age;
    }

    // Setter for age
    public void setAge(int age) {
        this.age = age;
    }

    // Main method to test the program
    public static void main(String[] args) {
        // Create a scanner to take user input
        Scanner sc = new Scanner(System.in);

        // Input for name and age
        System.out.print("Enter name: ");
        String name = sc.nextLine();
        
        System.out.print("Enter age: ");
        int age = sc.nextInt();

        // Create a new Person object using the constructor
        Person person = new Person(name, age);

        // Print the person's details using getters
        System.out.println("\nInitial Details:");
        System.out.println("Name: " + person.getName());
        System.out.println("Age: " + person.getAge());

        // Update the person's name and age using setters
        System.out.print("\nEnter updated name: ");
        sc.nextLine();  // Consume the newline
        String newName = sc.nextLine();

        System.out.print("Enter updated age: ");
        int newAge = sc.nextInt();

        person.setName(newName);
        person.setAge(newAge);

        // Print the updated details
        System.out.println("\nUpdated Details:");
        System.out.println("Name: " + person.getName());
        System.out.println("Age: " + person.getAge());

        // Close the scanner
        sc.close();
    }
}
