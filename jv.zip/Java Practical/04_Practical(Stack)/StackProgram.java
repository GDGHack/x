import java.util.Scanner;

interface StackOperations {
    void push(int item);
    void push(double item);
    void push(String item);
    int pop();
    double popDouble();
    String popString();
    int tos();
    double tosDouble();
    String tosString();
    boolean isEmpty();
    String toString();
    void display(); // Added display method to show stack contents
}

class IntegerStack implements StackOperations {
    private int[] stackArray;
    private int top;
    private int capacity;

    public IntegerStack(int capacity) {
        this.capacity = capacity;
        this.stackArray = new int[capacity];
        this.top = -1;
    }

    public void push(int item) {
        if (top == capacity - 1) {
            System.out.println("Stack is full!");
        } else {
            stackArray[++top] = item;
            System.out.println(item + " pushed to stack.");
        }
    }

    public int pop() {
        if (isEmpty()) {
            System.out.println("Stack is empty!");
            return -1;
        } else {
            return stackArray[top--];
        }
    }

    public int tos() {
        if (isEmpty()) {
            System.out.println("Stack is empty!");
            return -1;
        } else {
            return stackArray[top];
        }
    }

    public boolean isEmpty() {
        return top == -1;
    }

    public void push(double item) {
    }

    public void push(String item) {
    }

    public double popDouble() {
        return 0;
    }

    public String popString() {
        return null;
    }

    public double tosDouble() {
        return 0;
    }

    public String tosString() {
        return null;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        if (isEmpty()) {
            sb.append("Stack is empty.");
        } else {
            for (int i = 0; i <= top; i++) {
                sb.append(stackArray[i] + " ");
            }
        }
        return sb.toString();
    }

    @Override
    public void display() {
        if (isEmpty()) {
            System.out.println("Stack is empty.");
        } else {
            System.out.print("Stack contents: ");
            for (int i = 0; i <= top; i++) {
                System.out.print(stackArray[i] + " ");
            }
            System.out.println();
        }
    }
}

class DoubleStack implements StackOperations {
    private double[] stackArray;
    private int top;
    private int capacity;

    public DoubleStack(int capacity) {
        this.capacity = capacity;
        this.stackArray = new double[capacity];
        this.top = -1;
    }

    public void push(double item) {
        if (top == capacity - 1) {
            System.out.println("Stack is full!");
        } else {
            stackArray[++top] = item;
            System.out.println(item + " pushed to stack.");
        }
    }

    public double popDouble() {
        if (isEmpty()) {
            System.out.println("Stack is empty!");
            return -1;
        } else {
            return stackArray[top--];
        }
    }

    public double tosDouble() {
        if (isEmpty()) {
            System.out.println("Stack is empty!");
            return -1;
        } else {
            return stackArray[top];
        }
    }

    public boolean isEmpty() {
        return top == -1;
    }

    public void push(int item) {
    }

    public void push(String item) {
    }

    public int pop() {
        return 0;
    }

    public String popString() {
        return null;
    }

    public int tos() {
        return 0;
    }

    public String tosString() {
        return null;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        if (isEmpty()) {
            sb.append("Stack is empty.");
        } else {
            for (int i = 0; i <= top; i++) {
                sb.append(stackArray[i] + " ");
            }
        }
        return sb.toString();
    }

    @Override
    public void display() {
        if (isEmpty()) {
            System.out.println("Stack is empty.");
        } else {
            System.out.print("Stack contents: ");
            for (int i = 0; i <= top; i++) {
                System.out.print(stackArray[i] + " ");
            }
            System.out.println();
        }
    }
}

class StringStack implements StackOperations {
    private String[] stackArray;
    private int top;
    private int capacity;

    public StringStack(int capacity) {
        this.capacity = capacity;
        this.stackArray = new String[capacity];
        this.top = -1;
    }

    public void push(String item) {
        if (top == capacity - 1) {
            System.out.println("Stack is full!");
        } else {
            stackArray[++top] = item;
            System.out.println(item + " pushed to stack.");
        }
    }

    public String popString() {
        if (isEmpty()) {
            System.out.println("Stack is empty!");
            return null;
        } else {
            return stackArray[top--];
        }
    }

    public String tosString() {
        if (isEmpty()) {
            System.out.println("Stack is empty!");
            return null;
        } else {
            return stackArray[top];
        }
    }

    public boolean isEmpty() {
        return top == -1;
    }

    public void push(int item) {
    }

    public void push(double item) {
    }

    public int pop() {
        return 0;
    }

    public double popDouble() {
        return 0;
    }

    public int tos() {
        return 0;
    }

    public double tosDouble() {
        return 0;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        if (isEmpty()) {
            sb.append("Stack is empty.");
        } else {
            for (int i = 0; i <= top; i++) {
                sb.append(stackArray[i] + " ");
            }
        }
        return sb.toString();
    }

    @Override
    public void display() {
        if (isEmpty()) {
            System.out.println("Stack is empty.");
        } else {
            System.out.print("Stack contents: ");
            for (int i = 0; i <= top; i++) {
                System.out.print(stackArray[i] + " ");
            }
            System.out.println();
        }
    }
}

public class StackProgram {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Choose the type of stack:");
        System.out.println("1. Integer Stack");
        System.out.println("2. Double Stack");
        System.out.println("3. String Stack");
        System.out.print("Enter your choice: ");
        int choice = scanner.nextInt();
        System.out.print("Enter the size of the stack: ");
        int size = scanner.nextInt();

        StackOperations stack = null; 

        switch (choice) {
            case 1:
                stack = new IntegerStack(size);
                break;
            case 2:
                stack = new DoubleStack(size);
                break;
            case 3:
                stack = new StringStack(size);
                break;
            default:
                System.out.println("Invalid choice.");
                return;
        }

        while (true) {
            System.out.println("\nChoose an operation:");
            System.out.println("1. Push");
            System.out.println("2. Pop");
            System.out.println("3. Top of Stack (TOS)");
            System.out.println("4. Check if stack is empty");
            System.out.println("5. Display Stack");
            System.out.println("6. Exit");
            System.out.print("Enter your choice: ");
            int operation = scanner.nextInt();

            switch (operation) {
                case 1:
                    if (stack instanceof IntegerStack) {
                        System.out.print("Enter an integer: ");
                        int intValue = scanner.nextInt();
                        ((IntegerStack) stack).push(intValue);
                    } else if (stack instanceof DoubleStack) {
                        System.out.print("Enter a double: ");
                        double doubleValue = scanner.nextDouble();
                        ((DoubleStack) stack).push(doubleValue);
                    } else if (stack instanceof StringStack) {
                        System.out.print("Enter a string: ");
                        scanner.nextLine();
                        String stringValue = scanner.nextLine();
                        ((StringStack) stack).push(stringValue);
                    }
                    break;

                case 2:
                    if (stack instanceof IntegerStack) {
                        System.out.println("Popped: " + ((IntegerStack) stack).pop());
                    } else if (stack instanceof DoubleStack) {
                        System.out.println("Popped: " + ((DoubleStack) stack).popDouble());
                    } else if (stack instanceof StringStack) {
                        System.out.println("Popped: " + ((StringStack) stack).popString());
                    }
                    break;

                case 3:
                    if (stack instanceof IntegerStack) {
                        System.out.println("Top of Stack: " + ((IntegerStack) stack).tos());
                    } else if (stack instanceof DoubleStack) {
                        System.out.println("Top of Stack: " + ((DoubleStack) stack).tosDouble());
                    } else if (stack instanceof StringStack) {
                        System.out.println("Top of Stack: " + ((StringStack) stack).tosString());
                    }
                    break;

                case 4:
                    System.out.println("Is stack empty? " + stack.isEmpty());
                    break;

                case 5:
                    stack.display(); // Call the display method to show the stack contents
                    break;

                case 6:
                    System.out.println("Exiting...");
                    return;

                default:
                    System.out.println("Invalid operation!");
            }
        }
    }
}
