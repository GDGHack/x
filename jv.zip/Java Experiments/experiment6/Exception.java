import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;

public class Exception
{
    public  static void readfile() throws IOException
    {
        FileReader fr= new FileReader("not-exist.txt");
        BufferedReader br= new BufferedReader(fr);
        System.out.println(br.readLine());
        br.close();
    }


    public static void main(String[] args)
    {
        try{
            int num=10/0;

        }catch (ArithmeticException e){
            System.out.println(" exception"+e.getMessage());
        }


        try{
            int []arr={1,2,3};
            System.out.println(arr[5]);
        }catch (ArrayIndexOutOfBoundsException e)
        {
            System.out.println("array"+e.getMessage());
        }

        try{
            int n= Integer.parseInt("abc");

        }
        catch(NumberFormatException e)
        {
            System.out.println("error"+e.getMessage());
        }

        try{
            readfile();

        }catch(IOException e)
        {
            System.out.println("not found"+e. getMessage());
        }

        try{
            String str=null;
            System.out.println(str.length());
        }
        catch(NullPointerException e)
        {
            System.out.println("hii"+ e.getMessage());
        }

        finally{
            System.out.println("Always execute");
        }
        System.out.println("next execution");


    }
}