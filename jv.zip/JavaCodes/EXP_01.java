class Employee {
	private String fname;
	private String lname;
	private double salary;
	
	Employee(String fname, String lname, double salary) {
		this.fname = fname;
		this.lname = lname;
		this.salary = salary;
	}
	
	public String getfname() {
		return fname;
	}
	
	public String getlname() {
		return lname;
	}
	
	public double getSalary() {
		return salary;
	}
	
	public double getYearSalary() {
		return salary * 12;
	}
	
	public void setlname(String lname) {
		this.lname = lname;
	}
	
	public void setfname(String fname) {
		this.fname = fname;
	}
	
	public void setsalary(double salary) {
		if(salary > 0) {
			this.salary = salary;
		} else {
			this.salary = 0;
		}
	}
	
	public void salaryHike() {
		this.salary *= 1.10;
	}
}

class EXP_01 {
	public static void main(String[] args) {
		Employee emp1 = new Employee("Avishkar", "Patil", 300000);
		Employee emp2 = new Employee("Pruthvi", "Patil", 200000);
		
		System.out.println("Before Increment: ");
		System.out.println("\nName : " + emp1.getfname() + " " + emp1.getlname() + "\nMonthly Salary :" + emp1.getSalary() + "\nYearly Salary :" + emp1.getYearSalary());
		System.out.println("\nName : " + emp2.getfname() + " " + emp2.getlname() + "\nMonthly Salary :" + emp2.getSalary() + "\nYearly Salary :" + emp2.getYearSalary());
		
		emp1.salaryHike();
		emp2.salaryHike();
		
		System.out.println("After Increment: ");
		System.out.println("\nName : " + emp1.getfname() + " " + emp1.getlname() + "\nMonthly Salary :" + emp1.getSalary() + "\nYearly Salary :" + emp1.getYearSalary());
		System.out.println("\nName : " + emp2.getfname() + " " + emp2.getlname() + "\nMonthly Salary :" + emp2.getSalary() + "\nYearly Salary :" + emp2.getYearSalary());
		
	}
}
		