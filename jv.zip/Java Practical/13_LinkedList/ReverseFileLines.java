import java.io.*;
import java.util.*;

public class ReverseFileLines {
    public static void main(String[] args) {
        LinkedList<String> lines = new LinkedList<>();

        try {
            // Replace "input.txt" with your file path if needed
            BufferedReader reader = new BufferedReader(new FileReader("input.txt"));
            String line;

            // Read each line and add to LinkedList
            while ((line = reader.readLine()) != null) {
                lines.add(line);
            }
            reader.close();

            // Print lines in reverse order
            ListIterator<String> iterator = lines.listIterator(lines.size());
            while (iterator.hasPrevious()) {
                System.out.println(iterator.previous());
            }

        } catch (IOException e) {
            System.out.println("Error reading file: " + e.getMessage());
        }
    }
}