import java.util.*;
import java.io.*;

public class EXP_08 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the Name of File : ");
		String filename = sc.nextLine();
		
		File file = new File(filename);
		
		try {
			if(file.exists()) {
				System.out.println("Displaying the Content of File ");
				BufferedReader br = new BufferedReader(new FileReader(file));
				String line;
				while((line = br.readLine()) != null) {
					System.out.println(line);
				}
				br.close();
				
				System.out.println("1. Append data at the end of the file");
                System.out.println("2. Replace specified text in the file");
                System.out.print("Choose an option (1 or 2): ");
				
				int option = sc.nextInt();
				sc.nextLine();
				
				if(option == 1) {
					System.out.println("Enter Data to Append in File");
					String data = sc.nextLine();
					
					FileWriter fw = new FileWriter(file, true);
					fw.write(data + "\n");
					fw.close();
					System.out.println("Data Appended Successfully");
				} else if(option == 2) {
					System.out.println("Enter the data to replace:");
                    String oldData = sc.nextLine();
                    System.out.println("Enter the new data:");
                    String newData = sc.nextLine();
					
					
					StringBuilder sb = new StringBuilder();
					BufferedReader brr = new BufferedReader(new FileReader(file));
					while((line = brr.readLine()) != null) {
						sb.append(line.replace(oldData, newData)).append("\n");
					}
					
					br.close();
					
					FileWriter fww = new FileWriter(file, true);
					fww.write(sb.toString());
					fww.close();
					System.out.println("Data Replaced Successfully");
				} else {
					System.out.println("Invalid Option");
				}
				
			} else {
				System.out.print("File does not exist. Enter data to store in the new file: ");
                String data = sc.nextLine();
				
				FileWriter fw = new FileWriter(file);
                fw.write(data + "\n");
                fw.close();
                System.out.println("New file created and data stored.");
				
				
				System.out.println("Displaying contents of the new file:");
                BufferedReader br = new BufferedReader(new FileReader(file));
                String line;
                while ((line = br.readLine()) != null) {
                    System.out.println(line);
                }
                br.close();
			} 
		} catch (IOException e) {
			System.out.println(e.getMessage());
		}
		
		sc.close();
	}
}
				