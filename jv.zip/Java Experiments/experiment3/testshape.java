
abstract class Shape
{
    double side, area, perimeter;

    Shape(double side)
    { 
        this.side= side;
    }

    abstract void calarea();
    abstract void calperi();

    void display(){
        System.out.println(area);
        System.out.println(perimeter);
    }
}

 class triangle extends Shape{
    double height;
    triangle(double base, double height)
    {
        super( base);
        this.height= height;
    }

    void calarea()
    {
        area=(side*height)/2;
        
    }
     void calperi()
     {
        perimeter=3*side;
     }
    void display()
    {
        System.out.println("details of triangle");
        super.display();
    }

}


class rectangle extends Shape{
    double width;
    rectangle(double length, double width)
    {
        super(length);
        this.width= width;
    }

    void calarea()
    {
        area=side*width;
        
    }
     void calperi()
     {
        perimeter=2*(side+width);
     }
    void display()
    {
        System.out.println("details of rectangle");
        super.display();
    }

}

class square extends Shape{
    square(double side)
    {
        super(side);
    }

    void calarea()
    {
        area=side*side;
    }
    void calperi()
    {
        perimeter=4*side;
    }


    void display()
    {
        System.out.println("deatiuls of square");
        super.display();
    }
}

public class testshape
{
    public static void main(String [] args)
    {
        Shape s;

        s= new triangle(2,3);
        s.calarea();
        s.calperi();
        s.display();

        s= new rectangle(4,5);
        s.calarea();
        s.calperi();
        s.display();
        
        s= new square(5);
        s.calarea();
        s.calperi();
        s.display();
        
    }
}



