import javax.swing.*;
import java.awt.*;
import java.io.*;
import java.net.*;

public class ChatServer {
    private JFrame frame;
    private JTextArea textArea;
    private JTextField inputField;
    private PrintWriter out;

    public ChatServer() {
        frame = new JFrame("Chat Server");
        textArea = new JTextArea();
        inputField = new JTextField();

        textArea.setEditable(false);
        frame.setLayout(new BorderLayout());
        frame.add(new JScrollPane(textArea), BorderLayout.CENTER);
        frame.add(inputField, BorderLayout.SOUTH);

        inputField.addActionListener(e -> {
            String message = inputField.getText();
            out.println("Server: " + message);
            textArea.append("Me: " + message + "\n");
            inputField.setText("");
        });

        frame.setSize(400, 400);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);

        startServer();
    }

    private void startServer() {
        try (ServerSocket serverSocket = new ServerSocket(1234)) {
            textArea.append("Server started. Waiting for client...\n");
            Socket socket = serverSocket.accept();
            textArea.append("Client connected!\n");

            BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            out = new PrintWriter(socket.getOutputStream(), true);

            String line;
            while ((line = in.readLine()) != null) {
                textArea.append(line + "\n");
            }

        } catch (IOException ex) {
            textArea.append("Error: " + ex.getMessage());
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(ChatServer::new);
    }
}
