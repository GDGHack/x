import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

public class StopwatchApp extends JFrame implements ActionListener, Runnable {

    private JButton startButton, stopButton, lapButton, resetButton;
    private JLabel timeLabel;
    private JTextArea lapArea;
    private boolean running = false;
    private long startTime, elapsed;
    private Thread thread;
    private ArrayList<String> laps = new ArrayList<>();

    public StopwatchApp() {
        setTitle("Stopwatch");
        setSize(400, 400);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        timeLabel = new JLabel("00:00:00", SwingConstants.CENTER);
        timeLabel.setFont(new Font("Arial", Font.BOLD, 40));
        add(timeLabel, BorderLayout.NORTH);

        JPanel buttonPanel = new JPanel();
        startButton = new JButton("Start");
        stopButton = new JButton("Stop");
        lapButton = new JButton("Lap");
        resetButton = new JButton("Reset");

        buttonPanel.add(startButton);
        buttonPanel.add(stopButton);
        buttonPanel.add(lapButton);
        buttonPanel.add(resetButton);
        add(buttonPanel, BorderLayout.CENTER);

        lapArea = new JTextArea();
        lapArea.setEditable(false);
        add(new JScrollPane(lapArea), BorderLayout.SOUTH);

        startButton.addActionListener(this);
        stopButton.addActionListener(this);
        lapButton.addActionListener(this);
        resetButton.addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == startButton) {
            if (!running) {
                running = true;
                startTime = System.currentTimeMillis() - elapsed;
                thread = new Thread(this);
                thread.start();
            }
        } else if (e.getSource() == stopButton) {
            running = false;
        } else if (e.getSource() == lapButton) {
            if (running) {
                laps.add(formatTime(System.currentTimeMillis() - startTime));
                updateLapArea();
            }
        } else if (e.getSource() == resetButton) {
            running = false;
            elapsed = 0;
            laps.clear();
            timeLabel.setText("00:00:00");
            lapArea.setText("");
        }
    }

    @Override
    public void run() {
        while (running) {
            elapsed = System.currentTimeMillis() - startTime;
            timeLabel.setText(formatTime(elapsed));
            try {
                Thread.sleep(100);
            } catch (InterruptedException ex) {
                ex.printStackTrace();
            }
        }
    }

    private String formatTime(long timeMillis) {
        int seconds = (int) (timeMillis / 1000) % 60;
        int minutes = (int) (timeMillis / (1000 * 60)) % 60;
        int hours = (int) (timeMillis / (1000 * 60 * 60)) % 24;
        return String.format("%02d:%02d:%02d", hours, minutes, seconds);
    }

    private void updateLapArea() {
        StringBuilder sb = new StringBuilder();
        int lapCount = 1;
        for (String lap : laps) {
            sb.append("Lap ").append(lapCount++).append(": ").append(lap).append("\n");
        }
        lapArea.setText(sb.toString());
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new StopwatchApp().setVisible(true);
        });
    }
}
