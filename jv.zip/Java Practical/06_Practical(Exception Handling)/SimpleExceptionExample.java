import java.io.*;  // For handling file-related exceptions

public class SimpleExceptionExample {

    public static void main(String[] args) {
        // Example of runtime exception (ArithmeticException)
        try {
            int result = 10 / 0;  // This will throw an ArithmeticException
        } catch (ArithmeticException e) {
            System.out.println("Caught a runtime exception: " + e.getMessage());
        }

        // Example of compile-time exception (IOException)
        try {
            FileReader file = new FileReader("nonexistentfile.txt");  // This will throw a FileNotFoundException
        } catch (IOException e) {
            System.out.println("Caught a compile-time exception: " + e.getMessage());
        }

        System.out.println("Program finished.");
    }
}

