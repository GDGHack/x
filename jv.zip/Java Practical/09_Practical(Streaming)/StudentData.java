import java.io.*;
import java.util.Scanner;

public class StudentData implements Serializable {

    private String name;
    private int age;
    private double weight;
    private double height;
    private String city;
    private String phone;

    // Constructor to initialize the Student object
    public StudentData(String name, int age, double weight, double height, String city, String phone) {
        this.name = name;
        this.age = age;
        this.weight = weight;
        this.height = height;
        this.city = city;
        this.phone = phone;
    }

    // toString method to display student data
    @Override
    public String toString() {
        return "Name: " + name + "\nAge: " + age + "\nWeight: " + weight + "\nHeight: " + height
                + "\nCity: " + city + "\nPhone: " + phone;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Taking student information from the user
        System.out.print("Enter student name: ");
        String name = scanner.nextLine();

        System.out.print("Enter student age: ");
        int age = scanner.nextInt();

        System.out.print("Enter student weight: ");
        double weight = scanner.nextDouble();

        System.out.print("Enter student height: ");
        double height = scanner.nextDouble();

        scanner.nextLine();  // Consume the newline

        System.out.print("Enter student city: ");
        String city = scanner.nextLine();

        System.out.print("Enter student phone number: ");
        String phone = scanner.nextLine();

        // Creating a StudentData object
        StudentData student = new StudentData(name, age, weight, height, city, phone);

        // Serialize the student object into a file
        try (FileOutputStream fileOut = new FileOutputStream("student.dat");
             ObjectOutputStream objectOut = new ObjectOutputStream(fileOut)) {
            objectOut.writeObject(student);  // Serialize object into file
            System.out.println("Student data serialized to file.");
        } catch (IOException e) {
            e.printStackTrace();
        }

        // Deserialize the student object from the file
        try (FileInputStream fileIn = new FileInputStream("student.dat");
             ObjectInputStream objectIn = new ObjectInputStream(fileIn)) {
            StudentData deserializedStudent = (StudentData) objectIn.readObject();  // Deserialize the object
            System.out.println("\nStudent data retrieved from file:\n" + deserializedStudent);
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }

        scanner.close();
    }
}
