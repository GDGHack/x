import Package1.Name;

public class Main {
    public static void main(String[] args)
    {
        Name obj = new Name();

        obj.userName("Akash");
    }
}
