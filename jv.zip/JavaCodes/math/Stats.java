package math;

import java.util.Arrays;

public class Stats {
	public static double mean(double[] nums) {
		int sum = 0;
		for(double n: nums) {
			sum += n;
		}
		return sum /nums.length;
	}
	
	 public static double median(double[] nums) {
        Arrays.sort(nums);
        int mid = nums.length / 2;
    
        if (nums.length % 2 == 0) {
            return (nums[mid - 1] + nums[mid]) / 2.0;
        } else {
            return nums[mid];
        }
    }
	
	public static double standardDeviation(double[] nums) {
        double mean = mean(nums);
        double sum = 0;
        for (double num : nums)
            sum += Math.pow(num - mean, 2);
        return Math.sqrt(sum / nums.length);
    }
}
