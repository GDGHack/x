import java.io.*;

public class Exp6{

	public static void main(String[] args )
	{
		//int[] arr = {1,2,3,4,0};

		// String a = "ABC";
		//int b = Integer.parseInt(a);

		//int[] arr = null;



		try
		{
			fileRead();
			int a=10;
			int b = a/0;
			System.out.println(b);
		}
		catch(ArrayIndexOutOfBoundsException e)
		{
			System.out.println(e);
		}
		catch(NumberFormatException e)
		{
			System.out.println(e);
		}
		catch(NullPointerException e)
		{
			System.out.println(e);
		}
		catch(ArithmeticException e)
		{
			System.out.println(e);
		}
		catch(FileNotFoundException e)
		{	
			System.out.println(e);
		}
		finally
		{
			System.out.println("It is Always executed");
			
		}

	
	
	}//main end


	static void fileRead() throws FileNotFoundException
	{
		File f = new File("a.txt");
		FileReader fr = new FileReader(f);
	}
}