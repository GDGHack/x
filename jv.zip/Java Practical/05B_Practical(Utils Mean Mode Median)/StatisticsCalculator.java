package stats;

import java.util.*;

public class StatisticsCalculator {

    // Method to calculate Mean
    public static double mean(int[] numbers) {
        int sum = 0;
        for (int num : numbers) {
            sum += num;
        }
        return (double) sum / numbers.length;
    }

    // Method to calculate Mode (without using Map)
    public static int mode(int[] numbers) {
        int maxCount = 0;
        int mode = numbers[0];

        // Loop through each number in the array
        for (int i = 0; i < numbers.length; i++) {
            int count = 0;
            // Count how many times numbers[i] appears
            for (int j = 0; j < numbers.length; j++) {
                if (numbers[i] == numbers[j]) {
                    count++;
                }
            }
            // If the count is higher than the previous maxCount, update mode
            if (count > maxCount) {
                maxCount = count;
                mode = numbers[i];
            }
        }
        return mode;
    }

    // Method to calculate Median
    public static double median(int[] numbers) {
        Arrays.sort(numbers);  // Sort the array
        int length = numbers.length;

        // If odd number of elements, return the middle element
        if (length % 2 == 1) {
            return numbers[length / 2];
        } else {
            // If even number of elements, return the average of the two middle elements
            return (numbers[length / 2 - 1] + numbers[length / 2]) / 2.0;
        }
    }

    public static double standardDeviation(int[] numbers) {
        double mean = mean(numbers);
        int length = numbers.length;
        double sum = 0.0;
        for(int i = 0; i < length; i++){
            sum += Math.pow(numbers[i] - mean, 2);
        }
        return  Math.sqrt(sum / length);
    }
}


    

