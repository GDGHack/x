import java.io.*;
import java.util.*;


public class EXP_06 {
	public static void reader() throws IOException {
		FileReader fr = new FileReader("sample.txt");
		BufferedReader br = new BufferedReader(fr);
		System.out.println(br.readLine());	
		br.close();
	}
	
	public static void main(String[] args) {
		
		try {
			int num = 10/0;
			System.out.println(num);
		} catch (ArithmeticException e) {
			System.out.println("exception " + e.getMessage());
		}
		
		
		try {
			int []arr = {1, 2, 3};
			System.out.println(arr[5]);
		} catch (ArrayIndexOutOfBoundsException e) {
			System.out.println("exception array " + e.getMessage());
		}
		
		try {
			int num = Integer.parseInt("abc");
		} catch (NumberFormatException e) {
			System.out.println(e.getMessage());
		}
		
		
		try {
			reader();
		} catch (IOException e) {
			System.out.println(e.getMessage());
		}
		
		
		try {
			String str = null;
			System.out.println(str.length());
		} catch (NullPointerException e) {
			System.out.println(e.getMessage());
		}
			
	}
}