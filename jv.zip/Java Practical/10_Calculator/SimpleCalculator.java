import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class SimpleCalculator extends JFrame implements ActionListener 
{

    private JTextField display;
    private String expression = "";

    public SimpleCalculator() 
	{
        setTitle("Calculator");

        display = new JTextField();
        display.setEditable(false);
        display.setFont(new Font("Arial", Font.BOLD, 20));
        display.setHorizontalAlignment(SwingConstants.RIGHT);

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(5, 4, 10, 10));  
		

        
        JButton button7 = new JButton("7");
        JButton button8 = new JButton("8");
        JButton button9 = new JButton("9");
        JButton buttonDivide = new JButton("/");

        JButton button4 = new JButton("4");
        JButton button5 = new JButton("5");
        JButton button6 = new JButton("6");
        JButton buttonMultiply = new JButton("*");

        JButton button1 = new JButton("1");
        JButton button2 = new JButton("2");
        JButton button3 = new JButton("3");
        JButton buttonMinus = new JButton("-");

        JButton button0 = new JButton("0");
        JButton buttonDot = new JButton(".");
        JButton buttonEqual = new JButton("=");
        JButton buttonPlus = new JButton("+");

         
        JButton buttonClear = new JButton("Clear");
        JButton buttonDel = new JButton("Del");

        panel.add(button7);
        panel.add(button8);
        panel.add(button9);
        panel.add(buttonDivide);

        panel.add(button4);
        panel.add(button5);
        panel.add(button6);
        panel.add(buttonMultiply);

        panel.add(button1);
        panel.add(button2);
        panel.add(button3);
        panel.add(buttonMinus);

        panel.add(button0);
        panel.add(buttonDot);
        panel.add(buttonEqual);
        panel.add(buttonPlus);

        
        panel.add(buttonClear);
        panel.add(buttonDel);

         
        button7.addActionListener(this);
        button8.addActionListener(this);
        button9.addActionListener(this);
        buttonDivide.addActionListener(this);
        button4.addActionListener(this);
        button5.addActionListener(this);
        button6.addActionListener(this);
        buttonMultiply.addActionListener(this);
        button1.addActionListener(this);
        button2.addActionListener(this);
        button3.addActionListener(this);
        buttonMinus.addActionListener(this);
        button0.addActionListener(this);
        buttonDot.addActionListener(this);
        buttonEqual.addActionListener(this);
        buttonPlus.addActionListener(this);

         
        buttonClear.addActionListener(this);
        buttonDel.addActionListener(this);

        setLayout(new BorderLayout(10, 10));
        add(display, BorderLayout.NORTH);
        add(panel, BorderLayout.CENTER);

        setSize(400, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
    }

    @Override
    public void actionPerformed(ActionEvent e) 
	{
        JButton source = (JButton) e.getSource();
        String text = source.getText();

        if (text.equals("=")) 
		{
           
            try 
			{
                expression = evaluateExpression(expression);
                display.setText(expression);
            } catch (Exception ex) 
			{
                display.setText("Error");
            }
        } else if (text.equals("C")) 
		{
             
            expression = "";
            display.setText(expression);
        } else if (text.equals("Del")) 
		{
            
            if (!expression.isEmpty()) 
			{
                expression = expression.substring(0, expression.length() - 1);
                display.setText(expression);
            }
        } else 
		{
             
            expression += text;
            display.setText(expression);
        }
    }

    
    private String evaluateExpression(String expr) 
	{
        try 
		{
            
            expr = handleOperator(expr, '*', '/');
            
            expr = handleOperator(expr, '+', '-');
            return expr;  
        } catch (Exception e) 
		{
            return "Error";
        }
    }

    
    private String handleOperator(String expr, char operator1, char operator2) 
	{
        String[] tokens = expr.split("(?=[-+*/])|(?<=[-+*/])"); 
        double result = 0;
        boolean operatorFound = false;

      
        for (int i = 0; i < tokens.length; i++) 
		{
            
            if (tokens[i].equals(String.valueOf(operator1)) || tokens[i].equals(String.valueOf(operator2))) 
			{
                double num1 = Double.parseDouble(tokens[i - 1]);
                double num2 = Double.parseDouble(tokens[i + 1]);
                if (tokens[i].equals(String.valueOf(operator1))) 
				{
                    result = num1 * num2;
                } else if (tokens[i].equals(String.valueOf(operator2))) 
				{
                    result = num1 / num2;
                }
                 
                tokens[i - 1] = String.valueOf(result);
                tokens[i] = "0";
                tokens[i + 1] = "0";
                operatorFound = true;
            }
        }

        
        if (operatorFound)
		{
            return String.join("", tokens);
        }

        return expr;
    }

    public static void main(String[] args) 
	{
        SwingUtilities.invokeLater(new Runnable() 
		{
            public void run() 
			{
                SimpleCalculator calc = new SimpleCalculator();
                calc.setVisible(true);
            }
        });
    }
}
