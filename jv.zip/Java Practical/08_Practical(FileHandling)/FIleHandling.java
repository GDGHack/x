import java.io.*;
import java.util.Scanner;

class FileHandling{

    public static void main(String args[]){
        
        Scanner scanner = new Scanner(System.in);

        while(true){
            System.out.print("Enter the File Name :");

            String filename = scanner.nextLine();
            File file = new File(filename);
            
            if(file.exists())
            {
                System.out.println("\nFile Content :");
            }
        }
    }
}