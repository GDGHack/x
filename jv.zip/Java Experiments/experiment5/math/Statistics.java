package math;

import java.util.Arrays;

public class Statistics
{
    public static double mean(double[]numbers)
    {
        int sum=0;
        for(double n:numbers)
        {
            sum+=n;

        }

        return sum/numbers.length;
    }


    public static double median(double[] numbers) {
        Arrays.sort(numbers);
        int mid = numbers.length / 2;
    
        if (numbers.length % 2 == 0) {
            return (numbers[mid - 1] + numbers[mid]) / 2.0;
        } else {
            return numbers[mid];
        }
    }
    

    public static double standardDeviation(double[] numbers) {
        double mean = mean(numbers);
        double sum = 0;
        for (double num : numbers)
            sum += Math.pow(num - mean, 2);
        return Math.sqrt(sum / numbers.length);
    }
}