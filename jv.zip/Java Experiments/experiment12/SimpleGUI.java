import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class SimpleGUI {
    public static void main(String[] args) {
        JFrame frame = new JFrame("My GUI");
        frame.setSize(300, 200);
        frame.setLayout(null);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JLabel label = new JLabel("Enter name:");
        label.setBounds(20, 20, 100, 30);
        frame.add(label);

        JTextField textField = new JTextField();
        textField.setBounds(120, 20, 150, 30);
        frame.add(textField);

        JButton button = new JButton("Greet");
        button.setBounds(90, 70, 100, 30);
        frame.add(button);

        JLabel output = new JLabel("");
        output.setBounds(20, 110, 250, 30);
        frame.add(output);

        button.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String name = textField.getText();
                output.setText("Hello, " + name + "!");
            }
        });

        frame.setVisible(true);
    }
}
